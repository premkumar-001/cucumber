package stepDefinations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class parallelDefinition {
	WebDriver driver;

@Given("user on the site to test parallel")
public void user_on_the_site_to_test_parallel() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\verizon\\Day2-Selenium\\chromedriver.exe");
	driver=new ChromeDriver();
    Thread.sleep(3000);
	
    // Write code here that turns the phrase above into concrete actions
    //throw new io.cucumber.java.PendingException();
}
@When("url is launched{string} to test parallel")
public void url_is_launched_url_to_test_parallel(String url) throws InterruptedException {
	driver.navigate().to(url);
	Thread.sleep(3000);
	driver.manage().window().maximize();
	Thread.sleep(3000);
}

@Then("close  the site to test parallel")
public void close_the_site_to_test_parallel() {
   
    driver.close();
}



}
